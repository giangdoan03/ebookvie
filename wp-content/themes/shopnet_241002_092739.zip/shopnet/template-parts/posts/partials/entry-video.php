<?php 
/*
Template name: Page - Right Sidebar
 * @package          Flatsome\Templates
 * @flatsome-version 3.18.0
*/
?>
<a href="<?php the_permalink();?>">
    <?php the_post_thumbnail('large'); ?>
</a>