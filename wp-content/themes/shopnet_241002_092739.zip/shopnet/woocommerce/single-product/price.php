<?php
/**
 * Single Product Price, including microdata for SEO
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/price.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.0
 * @flatsome-version 3.18.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

$classes = array();
if($product->is_on_sale()) $classes[] = 'price-on-sale';
if(!$product->is_in_stock()) $classes[] = 'price-not-in-stock'; ?>
<div class="price-wrapper">
	<p class="price product-page-price <?php echo implode(' ', $classes); ?>">
  <?php echo $product->get_price_html(); ?></p> </div>
<p class="motangan">Ebook <?php the_title(); ?> của tác giả <?php the_terms( $post->ID, 'tac-gia', '', ', ', '' ); ?> đã có bản đẹp với định dạng <?php global $products;
$product_id = $product->id;
$product_tags = get_the_term_list($product_id, 'product_tag', '', ',' );
echo '<span class="single-product-tags">'. __( "", "flatsome" ) . $product_tags . '</span>';?>. Mời các bạn tải về eBook <?php the_title(); ?> miễn phí thông qua liên kết bên dưới.</p>

<?php $changelog=get_field('changelog'); ?>
<div class="thong-tin-ky-thuat">
     <div class="row-info">
    <div class="left">Thể loại</div>
    <div class="right"><?php global $post, $product;$categ = $product->get_categories();echo $categ; ?></div></div>

<div class="row-info">
<div class="left">Định dạng</div>
    <div class="right"><?php global $products;
$product_id = $product->id;
$product_tags = get_the_term_list($product_id, 'product_tag', '', ',' );
echo '<span class="single-product-tags">'. __( "", "flatsome" ) . $product_tags . '</span>';?></div></div>

    <div class="row-info">
    <div class="left">Tác giả</div>
    <div class="right"><?php the_terms( $post->ID, 'tac-gia', '', ', ', ' ' ); ?></div>
    </div>

    <div class="row-info">
    <div class="left">Nguồn</div>
    <?php if($changelog){?>
    <div class="right"><?php the_field('changelog');?></div>
    <?php } else {?>
    <div class="right">Đang cập nhật...</div>
    <?php }?>
    </div>

</div>
<?php 
global $post;
$slug = $post->post_name;
$domain = $_SERVER['HTTP_HOST'];
$field = get_field('file_epub');
if($field){
?>
<a target="_blank" href="https://<?php echo $domain;?>/doc-sach/<?php echo $slug;?>/" class="view-book"><i class="fas fa-book"></i> Đọc Sách Online</a>
<?php } ?>