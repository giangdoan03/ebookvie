<?php
/**
 * Single Product title
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 * @flatsome-version 3.18.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<h1 class="product-title product_title entry-title">
	<?php the_title(); ?>
</h1>
<?php setPostViews(get_the_ID()); ?>
<div class="tdk-product-loop-custom-product-meta">
<span class="last-updated-date"><i class="fas fa-eye"></i><span><?php 
   $a = getPostViews(get_the_ID());
	if ($a >= 1000) {
        $formatted_views_xem = round(($a / 1000)*1.3, 1) . 'K';
    } else {
        $formatted_views_xem = round($a*1.3);
    }
echo $formatted_views_xem;?></span></span>
<span class="version"><i class="fas fa-arrow-alt-circle-down"></i><?php 
   if ($a >= 1000) {
        $formatted_views_tai = number_format($a / 1000, 1) . 'K';
    } else {
        $formatted_views_tai = $a;
    }
echo $formatted_views_tai;?></span><span class="review1">4.5 <i class="star1"></i>
            <i class="star1"></i>
            <i class="star1"></i>
            <i class="star1"></i>
            <i class="star1 star2"></i>
</span></div>

<?php if(get_theme_mod('product_title_divider', 1)) { ?>
	<div class="is-divider small"></div>
<?php } ?>
